// Aby umożliwić działanie trigraphów należy dodać flagę -trigraphs do polecenia kompilatora
// ??= to #, ??/ to \, ??' to ^, ??( to [, ??) to ], ??! to |, ??< to {, ??> to}, ??- to ~

??=include <iostream>

int main() ??<
    std::cout << "??-" << std::endl;
    return 0;
??>