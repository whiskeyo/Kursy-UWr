g++ zadanie01.cpp -o zadanie01.out -std=c++17 -trigraphs;
g++ zadanie02.cpp -o zadanie02.out -std=c++17 -Wall -Wextra -Werror -pedantic;
g++ zadanie03.cpp -o zadanie03.out -std=c++17 -Wall -Wextra -Werror -pedantic;
g++ zadanie04.cpp -o zadanie04.out -std=c++17 -Wall -Wextra -Werror -pedantic;
g++ zadanie05.cpp -o zadanie05.out -std=c++17 -Wall -Wextra -Werror -pedantic;
g++ zadanie06.cpp -o zadanie06.out -std=c++17 -Wall -Wextra -Werror -pedantic;
g++ zadanie07.cpp -o zadanie07.out -std=c++17 -Wall -Wextra -Werror -pedantic;